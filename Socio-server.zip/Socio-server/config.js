import { Client, Account, Databases, Storage, Avatars } from 'appwrite'
import dotenv from "dotenv";

dotenv.config({path:'./config.env'});

export const appwriteConfig = {
    url: process.env.VITE_APPWRITE_URL || "https://cloud.appwrite.io/v1",
    projectId: process.env.VITE_APPWRITE_PROJECT_ID || "667c7b0f00312f83d8cb",
    databaseId: process.env.VITE_APPWRITE_DATABASE_ID || "667c8d750019bbe1a46e",
    storageId: process.env.VITE_APPWRITE_STORAGE_ID || "667c8d23002acab49636",
    usersCollectionId: process.env.VITE_APPWRITE_USER_COLLECTION_ID || "667c8dfe0031cfa581a9",
    postsCollectionId: process.env.VITE_APPWRITE_POST_COLLECTION_ID || "667c8dbe0037c0e01c19",
    savesCollectionId:process.env.VITE_APPWRITE_SAVES_COLLECTION_ID || "667c8e1e002943b1b232",
    messageCollectionId:process.env.VITE_APPWRITE_MESSAGE_COLLECTION_ID || "66941c5a00327255a686",
    reportCollectionId:process.env.VITE_APPWRITE_REPORT_COLLECTION_ID || "66999338000edc7e1d1f"

}

export const client = new Client();

client.setProject(appwriteConfig.projectId);
client.setEndpoint(appwriteConfig.url);


export const account = new Account(client);
export const databases = new Databases(client);
export const storage = new Storage(client);
export const avatars = new Avatars(client);


 