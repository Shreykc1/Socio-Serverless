const express = require('express');
const userRouter = require('./Routes/userRouter'); 
const authRouter = require('./Routes/authRouter'); 
const postsRouter = require('./Routes/postsRouter'); 
const messageRouter = require('./Routes/messageRouter'); 


const app = express();


app.use(bodyParser.json());
app.use(cors());
app.use('/user',userRouter);
app.use('/auth',authRouter);
app.use('/posts',postsRouter);
app.use('/message',messageRouter);




module.exports = app;