
import { ID } from 'appwrite';
import { account, appwriteConfig, avatars, databases} from "../config.js";
import { getCurrentUserId } from "./userController.js";
// ========================== USERS ===================================>


export async function createUserAccount(req,res) {
    const user = req.body;
    try {
      const newAccount = await account.create(
        ID.unique(),
        user.email,
        user.password,
        user.name
      );
  
      if (!newAccount) throw Error;
  
      const avatarUrl = avatars.getInitials(user.name);
  
      const newUser = await saveUserToDB({
        accountID: newAccount.$id,
        name: newAccount.name,
        email: newAccount.email,
        username: user.username,
        imageURL: avatarUrl,
      });
  
      res.send(newUser)
    } catch (error) {
      console.log(error);
      res.send({
        error: `Error creating account: ${error}`,
      })
    }
  }


export async function saveUserToDB(user) {
    try{
        const newUser = await databases.createDocument(
            appwriteConfig.databaseId,
            appwriteConfig.usersCollectionId,
            ID.unique(),
            user,
        )
        return newUser
    } catch(e){
        console.log(e)
    }
}


export async function signInAccount(req,res) {
    try {
        const user = req.body;
        const session = await account.createEmailPasswordSession(user.email, user.password);
        res.status(200).send(session);
    } catch (e) {
        console.error(e);
        res.send(500).send({
          error: `Error signing in: ${e}`,
        })
    }
}


export async function signOutAccount(req,res) {
  try {
    const session = await account.deleteSession("current")
    res.status(200).send(session);
  } catch (error) {
    res.send(500).send({
      error: `Error signing out: ${error}`,
    })
  }
}



export async function deleteAllActiveSessions() {
  try {
      // Fetch the current user's ID
      const userId = await getCurrentUserId();

      // Correctly list sessions for the current user
      const sessionsResponse = await account.listSessions();
      const sessions = sessionsResponse.sessions;

      // Assuming the current session is the latest one, or you have another criterion to identify it
      const currentSessionId = sessions[sessions.length - 1].$id; // Get the last session ID

      // Delete the identified session
      await account.deleteSession(currentSessionId);

      console.log("Current user's session deleted successfully.");
  } catch (error) {
      console.error("Failed to delete current user's session:", error);
  }
}




