
import { ID, Query } from 'appwrite';
import { appwriteConfig, databases} from "../config.js";
import { uploadFile, getFilePreview, deleteFile } from "./utilFunctions.js"


export async function createPost(post) {
    try {
      // Upload file to appwrite storage
      const uploadedFile = await uploadFile(post.file[0]);
  
      if (!uploadedFile) throw Error;
  
      // Get file url
      const fileUrl = getFilePreview(uploadedFile.$id);
      if (!fileUrl) {
        await deleteFile(uploadedFile.$id);
        throw Error;
      }
  
      // Convert tags into array
      const tags = post.tags?.replace(/ /g, "").split(",") || [];
  
      // Create post
      const newPost = await databases.createDocument(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        ID.unique(),
        {
          creator: post.userID,
          caption: post.caption,
          imageURL: fileUrl,
          imageID: uploadedFile.$id,
          location: post.location,
          tags: tags,
        }
      );
  
      if (!newPost) {
        await deleteFile(uploadedFile.$id);
        throw Error;
      }
  
      return newPost;
    } catch (error) {
      console.log(error);
    }
  }



  export async function searchPosts(searchTerm) {
    try {
      const posts = await databases.listDocuments(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        [Query.search("caption", searchTerm)]
      );
  
      if (!posts) throw Error;
  
      return posts;
    } catch (error) {
      console.log(error);
    }
  }


  export async function getInfinitePosts({ pageParam }) {
    const queries = [Query.orderDesc("$updatedAt"), Query.limit(9)];
  
    if (pageParam) {
      queries.push(Query.cursorAfter(pageParam.toString()));
    }
  
    try {
      const posts = await databases.listDocuments(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        queries
      );
  
      if (!posts) throw Error;
  
      return posts;
    } catch (error) {
      console.log(error);
    }
  }
  
  // ============================== GET POST BY ID
  export async function getPostById(postID) {
    if (!postID) throw Error;
  
    try {
      const post = await databases.getDocument(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        postID
      );
  
      if (!post) throw Error;
  
      return post;
    } catch (error) {
      console.log(error);
    }
  }
  
  // ============================== UPDATE POST
  export async function updatePost(post) {
    const hasFileToUpdate = post.file.length > 0;
  
    try {
      let image = {
        imageURL: post.imageURL,
        imageID: post.imageID,
      };
  
      if (hasFileToUpdate) {
        // Upload new file to appwrite storage
        const uploadedFile = await uploadFile(post.file[0]);
        if (!uploadedFile) throw Error;
  
        // Get new file url
        const fileUrl = getFilePreview(uploadedFile.$id);
        if (!fileUrl) {
          await deleteFile(uploadedFile.$id);
          throw Error;
        }
  
        image = { ...image, imageURL: fileUrl, imageID: uploadedFile.$id };
      }
  
      // Convert tags into array
      const tags = post.tags?.replace(/ /g, "").split(",") || [];
  
      //  Update post
      const updatedPost = await databases.updateDocument(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        post.postID,
        {
          caption: post.caption,
          imageURL: image.imageURL,
          imageID: image.imageID,
          location: post.location,
          tags: tags,
        }
      );
  
      // Failed to update
      if (!updatedPost) {
        // Delete new file that has been recently uploaded
        if (hasFileToUpdate) {
          await deleteFile(image.imageID);
        }
  
        // If no new file uploaded, just throw error
        throw Error;
      }
  
      // Safely delete old file after successful update
      if (hasFileToUpdate) {
        await deleteFile(post.imageID);
      }
  
      return updatedPost;
    } catch (error) {
      console.log(error);
    }
  }



//  ========================== REPOST =====================  > 

export async function rePost(post,user) {

  try {
    let image = {
      imageURL: post.imageURL,
      imageID: post.imageID,
    };

      image = { ...image, imageURL: post.imageURL, imageID: post.imageID };
    

    // Convert tags into array
    // const tags = post.tags?.replace(/ /g, "").split(",") || [];
    const tags = post.tags || [];

    const newPost = await databases.createDocument(
      appwriteConfig.databaseId,
      appwriteConfig.postsCollectionId,
      ID.unique(),
      {
        creator: user.id,
        caption: post.caption,
        imageURL: image.imageURL,
        imageID: image.imageID,
        location: post.location,
        tags: tags,
      }
    );

    // Failed to update
    if (!newPost) {

        await deleteFile(image.imageID);

      throw Error;
    }

    // Safely delete old file after successful update
    
      await deleteFile(post.imageID);
    

    return newPost;
  
  
} catch (error) {
    console.log(error);
  }
}

  
  // ============================== DELETE POST
  export async function deletePost(postID, imageID) {
    if (!postID || !imageID) return;
  
    try {
      const statusCode = await databases.deleteDocument(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        postID
      );
  
      if (!statusCode) throw Error;
  
      await deleteFile(imageID);
  
      return { status: "Ok" };
    } catch (error) {
      console.log(error);
    }
  }
  
  // ============================== LIKE / UNLIKE POST
  export async function likePost(postID, likesArray) {
    try {
      const updatedPost = await databases.updateDocument(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        postID,
        {
          likes: likesArray,
        }
      );
  
      if (!updatedPost) throw Error;
  
      return updatedPost;
    } catch (error) {
      console.log(error);
    }
  }
  
  // ============================== SAVE POST
  export async function savePost(userID, postID) {
    try {
      const updatedPost = await databases.createDocument(
        appwriteConfig.databaseId,
        appwriteConfig.savesCollectionId,
        ID.unique(),
        {
          user: userID,
          post: postID,
        }
      );
  
      if (!updatedPost) throw Error;
  
      return updatedPost;
    } catch (error) {
      console.log(error);
    }
  }



// ======================================== get saved posts//




export async function getSavedPosts(userID) {
  if (!userID) return;
  try {
    const getPost = await databases.listDocuments(
      appwriteConfig.databaseId,
      appwriteConfig.savesCollectionId,
      [
        Query.equal('user', userID)
      ]
    );

    if (!getPost.documents || getPost.documents.length === 0) {
      throw new Error('No posts found');
    }

    console.log('Fetched posts:', getPost.documents); // Log the fetched posts

    // Extract user and post fields manually
    const posts = getPost.documents.map(doc => ({
      user: doc.user,
      post: doc.post,
    }));

    return posts;
  } catch (error) {
    console.error('Error fetching saved posts:', error);
    throw error; // Re-throw the error to handle it in the hook
  }
}




  // ============================== DELETE SAVED POST
  export async function deleteSavedPost(savedRecordId) {
    try {
      const statusCode = await databases.deleteDocument(
        appwriteConfig.databaseId,
        appwriteConfig.savesCollectionId,
        savedRecordId
      );
  
      if (!statusCode) throw Error;
  
      return { status: "Ok" };
    } catch (error) {
      console.log(error);
    }
  }


  export async function getRecentPosts() {
    try {
      const posts = await databases.listDocuments(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        [Query.orderDesc("$createdAt"), Query.limit(10)]
      );
  
      if (!posts) throw Error;
  
      return posts;
    } catch (error) {
      console.log(error);
    }
  }




  export async function reportPost(choice,userID,postID) {
    try {
      const response = await databases.createDocument(
        appwriteConfig.databaseId,
        appwriteConfig.reportCollectionId,
        ID.unique(),
        {
          choice:choice,  
          users: [userID],
          posts: [postID]
        }
      )

      if (!response) throw Error;
      return response;
    } catch (error) {
      console.log(error);
    }
  }