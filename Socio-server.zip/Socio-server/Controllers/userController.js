
import { account, appwriteConfig, databases} from "../config.js";
import { Query } from 'appwrite';
import { uploadFile, getFilePreview, deleteFile } from "./utilFunctions.js"

export async function getCurrentUserId(){
    try {
        const currentUser = await account.get(); // Get the current user's information\
        return currentUser.$id
         // Return the user's ID
        
    } catch (error) {
        console.error("Failed to get current user's ID:", error);
        throw error;
    }
}


export async function getAccount() {
    try {
      const currentAccount = await account.get();
  
      return currentAccount;
    } catch (error) {
      console.log(error);
    }
  }


  



export async function getCurrentUser() {
    try {
      const currentAccount = await getAccount();
  
      if (!currentAccount) throw Error;
  
      const currentUser = await databases.listDocuments(
        appwriteConfig.databaseId,
        appwriteConfig.usersCollectionId,
        [Query.equal("accountID", currentAccount.$id)]
      );
  
      if (!currentUser) throw Error;
  
      return currentUser.documents[0];
    } catch (error) {
      console.log(error);
      return null;
    }
  }
  




  export async function updateProfile(values,user) {
    try {
      // Upload file to appwrite storage
      const uploadedFile = await uploadFile(values.file[0]);
  
      if (!uploadedFile) throw Error;
  
      // Get file url
      const fileUrl = getFilePreview(uploadedFile.$id);
      if (!fileUrl) {
        await deleteFile(uploadedFile.$id);
        throw Error;
      }
  
      // Update
      const updateDB = await databases.updateDocument(
        appwriteConfig.databaseId,
        appwriteConfig.usersCollectionId,
        user.id,
        {
          bio: values.bio,
          imageURL: fileUrl,
        }
      );
  
      if (!updateDB) {
        await deleteFile(uploadedFile.$id);
        throw Error;
      }
  
      return updateDB;
    } catch (error) {
      console.log(error);
    }
  }





  export async function getUsers(limit,verified) {
    const queries = [];
  
    if (limit) {
      queries.push(Query.limit(limit));
    }
    if (verified){
      queries.push(Query.orderDesc("isVerified"))
    }
  
    try {
      const users = await databases.listDocuments(
        appwriteConfig.databaseId,
        appwriteConfig.usersCollectionId,
        queries
      );
  
      if (!users) throw Error;
  
      return users;
    } catch (error) {
      console.log(error);
    }
  }



  



  
  // ============================== GET USER BY ID
  export async function getUserById(userID) {
    try {
      const user = await databases.getDocument(
        appwriteConfig.databaseId,
        appwriteConfig.usersCollectionId,
        userID
      );
  
      if (!user) throw Error;
  
      return user;
    } catch (error) {
      console.log(error);
    }
  }
  
  // ============================== UPDATE USER
  export async function updateUser(user) {
    const hasFileToUpdate = user.file.length > 0;
    try {
      let image = {
        imageURL: user.imageURL,
        imageID: user.imageID,
      };
  
      if (hasFileToUpdate) {
        // Upload new file to appwrite storage
        const uploadedFile = await uploadFile(user.file[0]);
        if (!uploadedFile) throw Error;
  
        // Get new file url
        const fileUrl = getFilePreview(uploadedFile.$id);
        if (!fileUrl) {
          await deleteFile(uploadedFile.$id);
          throw Error;
        }
  
        image = { ...image, imageURL: fileUrl, imageID: uploadedFile.$id };
      }
  
      //  Update user
      const updatedUser = await databases.updateDocument(
        appwriteConfig.databaseId,
        appwriteConfig.usersCollectionId,
        user.userID,
        {
          name: user.name,
          bio: user.bio,
          imageURL: image.imageURL,
          imageID: image.imageID,
          email: user.email
        }
      );
  
      // Failed to update
      if (!updatedUser) {
        // Delete new file that has been recently uploaded
        if (hasFileToUpdate) {
          await deleteFile(image.imageID);
        }
        // If no new file uploaded, just throw error
        throw Error;
      }
  
      // Safely delete old file after successful update
      if (user.imageID && hasFileToUpdate) {
        await deleteFile(user.imageID);
      }
  
      return updatedUser;
    } catch (error) {
      console.log(error);
    }
  }


  export async function getUserPosts(userID) {
    if (!userID) return;
  
    try {
      const post = await databases.listDocuments(
        appwriteConfig.databaseId,
        appwriteConfig.postsCollectionId,
        [Query.equal("creator", userID), Query.orderDesc("$createdAt")]
      );
  
      if (!post) throw Error;
  
      return post;
    } catch (error) {
      console.log(error);
    }
  }