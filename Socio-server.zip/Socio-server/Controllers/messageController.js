import { ID, Query } from 'appwrite';
import { appwriteConfig, databases} from "../config.js";

export async function fetchMessages(currentUser, selectedUser){
    try {
      const messages = await databases.listDocuments(
        appwriteConfig.databaseId, 
        appwriteConfig.messageCollectionId,
        [
          Query.or([
            Query.and([Query.equal('senderID', currentUser), Query.equal('recieverID', selectedUser)]),
            Query.and([Query.equal('senderID', selectedUser), Query.equal('recieverID', currentUser)])
          ]),
          Query.orderDesc('$createdAt')
        ]
    );
      if(!messages) throw Error;
      return messages;

    } catch (error) {
      console.log("Fetch msg: " ,error)
    }
  };
  
  export async function sendMessage(message) {
    const response = await databases.createDocument(
      appwriteConfig.databaseId, 
      appwriteConfig.messageCollectionId,
        ID.unique(),
        message
      );
    return response;
  };
  