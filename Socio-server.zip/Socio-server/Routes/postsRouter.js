const express = require('express');
const Router = express.Router();
const postsController = require('../Controllers/postsController')

Router.route('/createPost')
    .post(postsController.createPost)

Router.route('/searchPosts')
    .post(postsController.searchPosts);

Router.route('/getInfinitePosts')
    .post(postsController.getInfinitePosts);

Router.route('/getPostById')
    .post(postsController.getPostById);

Router.route('/updatePost')
    .post(postsController.updatePost);

Router.route('/rePost')
    .post(postsController.rePost);

Router.route('/deletePost')
    .post(postsController.deletePost);

Router.route('/likePost')
    .post(postsController.likePost);

Router.route('/savePost')
    .post(postsController.savePost);

Router.route('/getSavedPosts')
    .post(postsController.getSavedPosts);

Router.route('/deleteSavedPost')
    .post(postsController.rePost);

Router.route('/getRecentPosts')
    .post(postsController.getRecentPosts);

Router.route('/reportPost')
    .post(postsController.reportPost);


module.exports = Router;