const express = require('express');
const Router = express.Router();
const messageController = require('../Controllers/messageController')

Router.route('/fetchMessages')
    .post(messageController.fetchMessages)

Router.route('/sendMessage')
    .post(messageController.sendMessage);


module.exports = Router;