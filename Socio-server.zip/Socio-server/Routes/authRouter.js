const express = require('express');
const Router = express.Router();
const authController = require('../Controllers/authController')

Router.route('/createUserAccount')
    .post(authController.createUserAccount)

Router.route('/signInAccount')
    .post(authController.signInAccount);

Router.route('/signOutAccount')
    .get(authController.signOutAccount);

Router.route('/deleteAllActiveSessions')
    .get(authController.deleteAllActiveSessions);


module.exports = Router;