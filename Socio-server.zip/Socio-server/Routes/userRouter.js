const express = require('express');
const Router = express.Router();
const userController = require('../Controllers/userController')

Router.route('/getCurrentUserId')
    .get(userController.getCurrentUserId)

Router.route('/getUserById')
    .post(userController.getUserById);

Router.route('/getCurrentUser')
    .get(userController.getCurrentUser);

Router.route('/getUserPosts')
    .post(userController.getUserPosts);

Router.route('/updateUser')
    .post(userController.updateUser);

Router.route('/updateProfile')
    .post(userController.updateProfile);

Router.route('/getUsers')
    .get(userController.getUsers);


module.exports = Router;